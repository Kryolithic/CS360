package com.example.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button subBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        subBtn = findViewById(R.id.log_on);
    }

    public void submitCred(View view) {
        setContentView(R.layout.activity_calendar_screen);
    }
}